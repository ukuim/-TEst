class User {
    constructor(id, name, phone, img) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.img = img;
    }
}
import { Header } from '@bundle:com.example.myapplication/entry/ets/Components/TitleComponent/Title';
function UserCard(User, parent = null) {
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Row.create();
        Row.debugLine("pages/UserPage.ets(16:3)");
        Row.width("100%");
        Row.backgroundColor("#36d");
        Row.padding(20);
        Row.margin(5);
        Row.height(120);
        Row.borderRadius(20);
        Row.justifyContent(FlexAlign.SpaceEvenly);
        if (!isInitialRender) {
            Row.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Column.create();
        Column.debugLine("pages/UserPage.ets(17:5)");
        Column.alignItems(HorizontalAlign.Start);
        Column.height(120);
        if (!isInitialRender) {
            Column.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Image.create({ "id": 16777225, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
        Image.debugLine("pages/UserPage.ets(18:7)");
        Image.height(90);
        if (!isInitialRender) {
            Image.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Text.create(User.phone);
        Text.debugLine("pages/UserPage.ets(20:7)");
        Text.fontSize(20);
        if (!isInitialRender) {
            Text.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    Text.pop();
    Column.pop();
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Column.create();
        Column.debugLine("pages/UserPage.ets(25:5)");
        Column.justifyContent(FlexAlign.SpaceEvenly);
        Column.height(120);
        if (!isInitialRender) {
            Column.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Text.create(User.id.toFixed());
        Text.debugLine("pages/UserPage.ets(26:7)");
        Text.fontSize(20);
        if (!isInitialRender) {
            Text.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    Text.pop();
    (parent ? parent : this).observeComponentCreation((elmtId, isInitialRender) => {
        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
        Text.create(User.name);
        Text.debugLine("pages/UserPage.ets(28:7)");
        Text.fontSize(20);
        if (!isInitialRender) {
            Text.pop();
        }
        ViewStackProcessor.StopGetAccessRecording();
    });
    Text.pop();
    Column.pop();
    Row.pop();
}
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.users = [
            new User(1, 'Alice', '1234567890', "img"),
            new User(2, 'Bob', '9876543210', "img"),
            new User(3, 'Charlie', '5555555555', "img"),
            new User(4, 'David', '1112223333', "img"),
            new User(5, 'Eve', '9998887777', "img"),
            new User(1, 'Alice', '1234567890', "img"),
            new User(2, 'Bob', '9876543210', "img"),
            new User(3, 'Charlie', '5555555555', "img"),
            new User(4, 'David', '1112223333', "img"),
            new User(5, 'Eve', '9998887777', "img"),
        ];
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.users !== undefined) {
            this.users = params.users;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 8 });
            Column.debugLine("pages/UserPage.ets(58:5)");
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new Header(this, { title: "商品列表" }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        /*
              ForEach(
                this.users,
                (User: User) => {
                  Row() {
                    Column() {
                      Image($r("app.media.icon"),)
                        .height(90)
                      Text(User.phone)
                        .fontSize(20)
                    }.alignItems(HorizontalAlign.Start)
                    .height(120)
        
                    Column() {
                      Text(User.id.toFixed())
                        .fontSize(20)
                      Text(User.name)
                        .fontSize(20)
                    }.justifyContent(FlexAlign.SpaceEvenly)
                    .height(120)
                  }
                  .width("100%")
                  .backgroundColor("#36d")
                  .padding(20)
                  .margin(5)
                  .height(120)
                  .borderRadius(20)
                  .justifyContent(FlexAlign.SpaceEvenly)
                }
              )*/
        this.ListFrom.bind(this)(8);
        Column.pop();
    }
    //局部
    ListFrom(num, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create({ space: num });
            List.debugLine("pages/UserPage.ets(99:5)");
            List.width("100%");
            List.layoutWeight(1);
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const User = _item;
                {
                    const isLazyCreate = true;
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, isLazyCreate);
                        ListItem.debugLine("pages/UserPage.ets(103:11)");
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        ListItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        UserCard.bind(this)(User);
                        ListItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        UserCard.bind(this)(User);
                        ListItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, this.users, forEachItemGenFunction);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        List.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Index(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=UserPage.js.map